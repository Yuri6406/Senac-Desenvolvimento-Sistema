package exercicios;

public class ProgramaEX01 {

	public static void main(String[] args) {

		int num = 10;
		
		if (num > 0) {
			System.out.println("Este número é pôsitivo");
		}else if (num < 0){
			System.out.println("Este número é negativo ");
		}else {
			System.out.println("Este número é ZERO");
		}
		
	}

}
