package exercicios;

public class ProgramaEX02 {

	public static void main(String[] args) {

		int num = 0;
		
		if (num % 2 == 0) {
			System.out.println("O númeor informado é Par");
		}else{
			System.out.println("O número informado é Impar");
		}
	}

}
