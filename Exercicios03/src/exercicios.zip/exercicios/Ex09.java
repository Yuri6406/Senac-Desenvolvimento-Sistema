package exercicios;

public class Ex09 {

	public static void main(String[] args) {
		
		int res = 0;
		for (int i = 0; i <= 100; i++) {
			res = res + i;
		}
		System.out.println(res);
	}
}